import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage

def sendmail(smtp_server, sender_email, port, password, haveSSL, haveTLS, receiver_email, subject):

    # Create the root message and fill in the from, to, and subject headers
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = sender_email
    msgRoot['To'] = receiver_email
    msgRoot.preamble = 'This is a multi-part message in MIME format.'

    # Encapsulate the plain and HTML versions of the message body in an
    # 'alternative' part, so message agents can decide which they want to display.
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)

    msgText = MIMEText('This is the alternative plain text message.')
    msgAlternative.attach(msgText)

    # We reference the image in the IMG SRC attribute by the ID we give it below
    with open("HTML MODELO/result.html", "r") as inf_html:
        html = inf_html.read()
    msgText = MIMEText(html, 'html')
    msgAlternative.attach(msgText)


    # This example assumes the image is in the current directory
    fp = open('result.png', 'rb')
    msgImage = MIMEImage(fp.read())
    fp.close()

    # Define the image's ID as referenced above
    msgImage.add_header('Content-ID', '<result>')
    msgRoot.attach(msgImage)

    # Create a secure SSL context
    context = ssl.create_default_context()

    if haveSSL:
        if haveTLS: #TLS
            print("Email: com SSL e TLS")
            # Try to log in to server and send email
            with smtplib.SMTP_SSL(smtp_server,port) as server:
                server.ehlo() 
                server.starttls(context=context)
                server.ehlo() 
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email.split(','), msgRoot.as_string())


        else: #not TLS
            print("Email: com SSL e sem TLS")
            with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email.split(','), msgRoot.as_string())

    else:
        if haveTLS: #TLS
            print("Email: sem SSL e com TLS")
            with smtplib.SMTP(smtp_server, port) as server:
                server.ehlo()  
                server.starttls(context=context)
                server.ehlo()  
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email.split(','), msgRoot.as_string())

        else: #not TLS
            print("Email: sem SSL e sem TLS")
            with smtplib.SMTP(smtp_server, port) as server:
                server.ehlo()  
                server.ehlo()  
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email.split(','), msgRoot.as_string())
