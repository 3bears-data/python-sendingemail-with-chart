import pyodbc #para conexao com o banco
import bs4 #para manipular o html
from bs4 import UnicodeDammit #para olhar o charset
import json #carrega variaveis
import chart #monta o grafico
import mail #monta o email
import sys #executa o comando de saida
import os #remove arquivos antigos
import time #adiciona um wait/sleep
import datetime #condição para o greeting

def montaTH(cl):
    default = "<th>@</th>"
    return  default.replace("@", str(cl))

def montaTD(valor):
    default = "<td>@</td>"
    return default.replace("@", str(valor))

def montaTR(valor):
    default = "<tr>@</tr>"
    return default.replace("@", str(valor))

jsnConexaoEmail = open('varConexaoEmail.json')
varConexaoEmail = json.load(jsnConexaoEmail)
jsnConexaoBanco = open('varConexaoBanco.json')
varConexaoBanco = json.load(jsnConexaoBanco)
jsnResultado = open('varResultado.json')
varResultado = json.load(jsnResultado)

#### VARIAVEIS DE CONEXAO DO BANCO ####
Driver = varConexaoBanco['CONEXAO']['Driver']
Server = varConexaoBanco['CONEXAO']['Server']
Database = varConexaoBanco['CONEXAO']['Database']
Uid = varConexaoBanco['CONEXAO']['Uid']
Pwd = varConexaoBanco['CONEXAO']['Pwd']

#### VARIAVEIS DE CONEXAO DO EMAIL ####
smtp_server = varConexaoEmail['CONEXAO']['smtp_server']
sender_email = varConexaoEmail['CONEXAO']['sender_email']
port = varConexaoEmail['CONEXAO']['port']
password = varConexaoEmail['CONEXAO']['password']
haveSSL = varConexaoEmail['CONEXAO']['haveSSL']
haveTLS = varConexaoEmail['CONEXAO']['haveTLS']

#### VARIAVEIS DE RESULTADO ####
strSQL = varResultado['GRAFICO']['query']
titulo = varResultado['GRAFICO']['titulo'].encode('latin1').decode('utf8')
receiver_email = varResultado['EMAIL']['receiver_email']
subject = varResultado['EMAIL']['subject'].encode('latin1').decode('utf8')
assinatura = varResultado['EMAIL']['assinatura'].encode('latin1').decode('utf8')
second_line = varResultado['EMAIL']['second_line'].encode('latin1').decode('utf8')

try:
    print("Apagando result anteriores...")
    os.remove("HTML MODELO/result.html") 
    os.remove("result.png") 
except:
    print("Nenhum arquivo para apagar.")
    

print("Conectando no banco...")

conn = pyodbc.connect('Driver={' + Driver + '};'
                      'Server=' + Server + ';'
                      'Database=' + Database + ';'
                      'Uid=' + Uid + ';'
                      'Pwd=' + Pwd + ';'
                      )

cursor = conn.cursor()
cursor.execute(strSQL)

print("Montando o HTML...")

#### MONTA A TAG TH ####
columns = [column[0] for column in cursor.description]
header = ""
for cl in columns:
    header = header + montaTH(cl)


#### MONTA A TAG TD e TR ####
tagTR = ""

x = []
y = []

isEmpty = True
for row in cursor:
    tagTD = ""
    coluna = 0
    dtRef = ""

    for valor in row:
        isEmpty = False #encontrou valores entao dataset nao esta vazio
        coluna += 1
        tagTD = tagTD + montaTD(valor)

        if coluna == 1:
            y.append(valor)
        elif coluna == 2:
            x.append(valor)
        elif coluna == 3:
            dtRef = valor
    
    tagTR = tagTR + montaTR(tagTD) 

if isEmpty:
    print("Não há resultados no dataset da query")
    sys.exit()

currentTime = datetime.datetime.now()
if currentTime.hour < 12:
    greeting = 'bom dia'
elif 12 <= currentTime.hour < 18:
    greeting = 'boa tarde'
else:
    greeting = 'boa noite'


#### ABRE HTML MODELO E SUBSTITUI VARIAVEIS ####
with open("HTML MODELO/example.html", "r") as inf:
    txt = inf.read()
    txt = txt.replace("heaxder", header)
    txt = txt.replace("boxdy", tagTR)
    txt = txt.replace("sexgue", second_line)
    txt = txt.replace("assxinatura", assinatura)
    txt = txt.replace("bomxdia", greeting)

#### SALVA O RESULTADO ####
with open("HTML MODELO/result.html", "w") as outf:
    outf.write(str(txt))

#### GERA O PNG ####
print("Gerando o PNG...")
chart.generatePNG(y, x, dtRef, titulo)
time.sleep(4) #3 segundos para garantir que o arquivo foi gerado


#### ENVIANDO O EMAIL ###
print("Enviando o E-mail...")
if haveSSL == "True":
    haveSSL = True
else:
    haveSSL = False

if haveTLS == "True":
    haveTLS = True
else:
    haveTLS = False

print("Assunto: ", subject)
print("Destinatario: ", receiver_email)

mail.sendmail(smtp_server, sender_email, port, password, haveSSL, haveTLS, receiver_email, subject)


#### APAGANDO ARQUIVOS DE RESULTADO ###
try:
    print("Apagando result...")
    os.remove("HTML MODELO/result.html") 
    os.remove("result.png") 

except:
    print("Nenhum resultado")