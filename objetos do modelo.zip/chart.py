import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import FancyBboxPatch

def generatePNG(xvalue, yvalues, datevalue, titulo):
    x = xvalue
    y = yvalues

    fig, ax = plt.subplots()    
    width = 0.65 
    ind = np.arange(len(y)) 

    plt.title(titulo + ' (' + str(datevalue) + ')', fontweight='bold', color='#595959')

    ax.barh(ind, y, width, color="#44546A")
    ax.set_yticks(ind+width/2)
    ax.set_yticklabels(x, minor=False, color="#595959", font="calibri", fontweight="bold")

    bbox = dict(boxstyle="round", ec="#40BA8E", fc="#40BA8E", alpha=0.5)

    for i, v in enumerate(y):
        ax.text(v , i + .25, str(v), color='black', fontweight='normal', bbox=bbox)

    ax.axes.xaxis.set_ticklabels([])

    #plt.xlabel('x')
    #plt.ylabel('y')    

    plt.grid(linestyle = '--', linewidth = 0.5, color = '#A6A6A6')
    ax.set_axisbelow(True)

    plt.gcf().subplots_adjust(left=0.15)  
    plt.tight_layout()

    #plt.show()
    plt.savefig('result.png') 



